import java.io.*;
import java.text.*;

/**
 * Escreva a descrição da classe Coordenadas aqui.
 * 
 * @author Cláudia Marques
 * @version 0.1
 */
public class Localização
{
    private double x, y;
    
    /**
     *  Construtor vazio, ou seja, inicia as coordenadas a 0.
     */
    public Localização(){
        this.x=0;
        this.y=0;
    }
    
    /**
     * Construtor parametrizado, ou seja, recebe a localização(expressa em x e y) e cria uma coordenada com esses valores.
     * @param   x     
     * @param   y     
     */
    public Localização(double x, double y){
        this.x=x;
        this.y=y;
    }
    
    /**
     * Construtor por cópia, ou seja, copia os dados de uma Coordenada já existente.
     * @param   c   Coordenadas que irão ser copiadas.
     */
   
    public Localização(Localização l){
        this.x = l.getX();
        this.y = l.getY();
    }
    
    /*
     * GETS
     */
    
     /**
     * A função getX devolve a latitude de uma Coordenada.
     */
    public double getX(){ return x; }
    
     /**
     * A função getY devolve a latitude de uma Coordenada.
     */
    public double getY(){ return y; }
    
    /*
     * SETS
     */
    /**
     * A função setX altera a latitude de uma Coordenada.
     * @param lat Valor da latitude que irá substituir a latitude.
     */
    public void setX(double x){ this.x=x; }
    
    /**
     * A função setY altera a latitude de uma Coordenada.
     * @param lat Valor da latitude que irá substituir a latitude.
     */
    public void setY(double y){ this.y=y; }
    
    /*
     * Funções aux
     */
    
    /**
     * A função toString imprimi uma Coordenada, ou seja, imprime a latitude e longitude da mesma.
     * @param c A coordenada que irá ser impressa.
     */
    public StringBuilder toString(Localização c){
       StringBuilder str = new StringBuilder();
       str.append( "X "  + c.getX());
       str.append("Y " + c.getY());
                     
       return str;
    }
    
    /**
     * A função equals recebe um Objesto genérico e verifica se é exatamente igual a uma Coordenada.
     * @param obj Objecto a comparar.
     */
    public boolean equals(Object obj){
        if(this == obj) return true;
        if((obj == null) || (this.getClass() != obj.getClass())) return false;
        
        Localização c = (Localização) obj;
        
        return(this.x==c.getX() && this.y==c.getY());
    }
    
    /**
     * A função clone faz um clone de uma Coordenada, a partir do construtor por cópia.
     */
    public Localização clone(){
        return new Localização(this);
    }
    
}
